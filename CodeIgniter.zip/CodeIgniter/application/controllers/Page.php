<?php
class Page extends CI_Controller{

  public function __construct()
      {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Db_model');
      }

  public function afficher()

        {
                  	$this->load->view('home');


        }


}






 ?>
