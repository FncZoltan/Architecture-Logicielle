package voiture.impl;

public class TestVoitureFactory {

	public static void main(String[] args) {
		
		VoitureFactory vf = new VoitureFactory();
		Voiture v = vf.makeVoiture("Seat", "Leon", 12345, "Michelin", 10.0, 20.0, false);
		System.out.println(v.toString());
		
	}

}
