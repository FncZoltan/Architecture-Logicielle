package voiture.impl;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.FileWriter;
import java.io.IOException;

public class VoitureFactoryJSON {
	
	
	public Voiture makeVoiture(){
		JSONObject obj = new JSONObject();
		obj.put(key, value)
		return null;
	}

}
