package voiture.impl;

public class VoitureFactory {

	public static int nbrpneus = 4;
	public int nbrVoiture = 0;
	
	public Voiture makeVoiture (String marqueVoiture,String modeleVoiture,int numeroSerie,String marquePneu, double largeur, double hauteur,boolean hiver){
		
		Voiture v = new Voiture();
		v.setMarque(marqueVoiture);
		v.setModele(modeleVoiture);
	
		Moteur m = new Moteur();
		m.setNumeroSerie(numeroSerie);
		v.setMoteur(m);

		
		Pneu p = new Pneu();
		
		for(int i=0;i<nbrpneus;i++){
			p.setMarque(marquePneu);
			p.setHauteur(hauteur);
			p.setLargeur(largeur);
			p.setHiver(hiver);	
			v.getPneus().add(p);
		}
		nbrVoiture ++;
		return v;
	}
	
		

}
